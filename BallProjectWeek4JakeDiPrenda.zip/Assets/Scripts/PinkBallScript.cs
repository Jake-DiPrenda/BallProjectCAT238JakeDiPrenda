using UnityEngine;

public class PinkBallScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject pinkBall;

    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Oh, Hello. This is the PinkBallScript's Start ;p");
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.D))
        {
            Debug.Log("The Right key is pressed.");

            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.A))
        {
            Debug.Log("The Left key is pressed.");

            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.Space))
        {
            Debug.Log("The Up key is pressed.");
            Jump();
        }
    }

    void Jump()
    {
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}
