using UnityEngine;

public class GreenBallScript : MonoBehaviour
{

    public float moveSpeed;
    public float jumpForce;
    public GameObject greenBall;

    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Oh, Hello. This is the GreenBallScript's Start ;p");
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(Input.GetKey(KeyCode.RightArrow)) 
        {
            Debug.Log("The Right key is pressed.");

            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            Debug.Log("The Left key is pressed.");

            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.Space))
        {
            Debug.Log("The Up key is pressed.");
            Jump();
        }
    }

    void Jump()
    {
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}
