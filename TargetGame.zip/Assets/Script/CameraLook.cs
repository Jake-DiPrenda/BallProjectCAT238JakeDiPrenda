using UnityEngine;

public class CameraLook : MonoBehaviour
{
    [SerializeField] private float _sensX;
    [SerializeField] private float _sensY;

    private float rotationX;
    private float rotationY;

    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Awake()
    {
        //will hide the cursor on start
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    // Update is called once per frame
    void Update()
    {
        //finds where mouse is
        float mouseX = Input.GetAxisRaw("Mouse X") * _sensX;
        float mouseY = Input.GetAxisRaw("Mouse Y") * _sensY;
        rotationY += mouseX;

        rotationX -= mouseY;

        rotationX = Mathf.Clamp(rotationX, -67.5f, 67.5f);
    }
    private void LateUpdate()
    {
        //moves camera
        transform.rotation = Quaternion.Euler(rotationX, rotationY, 0);
    }
}
