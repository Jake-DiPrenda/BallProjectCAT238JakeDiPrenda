using UnityEngine;

public class SpawnTarget : MonoBehaviour
{
    public GameObject target;
    public Vector3 minBounds = new Vector3(-10f, 1f, 0f);
    public Vector3 maxBounds = new Vector3(10f, 1f, 0f);
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        SpawnTargets();
    }

    public void SpawnTargets() 
    {
        float randomX = Random.Range(minBounds.x, maxBounds.x);
        float randomY = Random.Range(minBounds.y, maxBounds.y);
        float randomZ = Random.Range(minBounds.z, maxBounds.z);

        Vector3 randomPosition = new Vector3(randomX, randomY, randomZ);

        Instantiate(target, randomPosition, Quaternion.identity);
    }
}
