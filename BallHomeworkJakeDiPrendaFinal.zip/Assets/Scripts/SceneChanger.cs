using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
public class SceneChanger : MonoBehaviour
{

    void OnCollisionEnter2D(Collision2D other) 
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("collision detected");
            ChangeScene();
        }
    }

    void ChangeScene()
    {
        SceneManager.LoadScene(1);
    }
}
