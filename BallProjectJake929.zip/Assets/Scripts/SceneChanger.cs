using UnityEngine;
using UnityEngine.SceneManagement;
public class SceneChanger : MonoBehaviour
{

    private void OnTriggerEnter(Collider2D other) 
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("collision detected");
            SceneManager.LoadScene(1);
        }
    }
}
