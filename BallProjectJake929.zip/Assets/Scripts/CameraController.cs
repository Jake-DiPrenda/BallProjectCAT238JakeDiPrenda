using UnityEngine;

public class CameraController : MonoBehaviour
{
    public GameObject greenRoundie_0;

    void Update()
    {
        transform.position = new Vector3(greenRoundie_0.transform.position.x, transform.position.y, transform.position.z);
    }
}
